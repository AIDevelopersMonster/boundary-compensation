#!/usr/bin/env python3
"""BC-M-D1: reconstruct a real 3x3 Jacobi matrix from
known eigenvalues and two real anchored resolvent probes.

This is a finite-dimensional reproducibility companion, not a proof engine
and not a certified floating-point package.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from typing import Sequence

import numpy as np


@dataclass
class D1Report:
    status: str
    eigenvalues: list[float]
    probe_points: list[float]
    probe_values: list[float]
    weights: list[float] | None
    jacobi_matrix: list[list[float]] | None
    determinant_A: float | None
    sigma_min_A: float | None
    condition_number_A: float | None
    spectral_residual_l2: float | None
    probe_residual_l2: float | None
    positivity_margin: float | None
    irreducibility_margin: float | None
    warnings: list[str]
    spectral_separation_margin: float | None = None
    probe_clearance_margin: float | None = None
    probe_independence_margin: float | None = None
    irreducibility_margin_sq: float | None = None
    irreducibility_threshold_sq: float | None = None
    irreducibility_status: str | None = None


def anchored_resolvent(J: np.ndarray, z: float) -> float:
    """Return e1^T (z I - J)^(-1) e1."""
    e1 = np.array([1.0, 0.0, 0.0])
    x = np.linalg.solve(z * np.eye(3) - J, e1)
    return float(e1 @ x)


def build_augmented_cauchy(eigenvalues: np.ndarray, probes: np.ndarray) -> np.ndarray:
    rows = [np.ones(3)]
    for z in probes:
        rows.append(1.0 / (z - eigenvalues))
    return np.vstack(rows)


def reconstruct_from_weights(eigenvalues: np.ndarray, weights: np.ndarray, tol: float) -> np.ndarray:
    moments = np.array(
        [float(np.sum(weights * eigenvalues**j)) for j in range(5)],
        dtype=float,
    )
    m1, m2, m3, m4 = moments[1], moments[2], moments[3], moments[4]

    a1 = m1
    b1_sq = m2 - m1 * m1
    if b1_sq <= tol:
        raise ValueError(f"b1^2 is not strictly positive: {b1_sq}")
    b1 = math.sqrt(b1_sq)

    a2 = (m3 - a1**3 - 2.0 * a1 * b1_sq) / b1_sq
    b2_sq = (
        m4
        - (a1 * a1 + b1_sq) ** 2
        - b1_sq * (a1 + a2) ** 2
    ) / b1_sq
    if b2_sq <= tol:
        raise ValueError(f"b2^2 is not strictly positive: {b2_sq}")
    b2 = math.sqrt(b2_sq)

    a3 = float(np.sum(eigenvalues) - a1 - a2)
    return np.array(
        [[a1, b1, 0.0], [b1, a2, b2], [0.0, b2, a3]],
        dtype=float,
    )


def reconstruct(
    eigenvalues: Sequence[float],
    probe_points: Sequence[float],
    probe_values: Sequence[float],
    tol: float = 1e-10,
    conditioning_threshold: float = 1e-8,
    irreducibility_threshold_sq: float = 1e-6,
) -> D1Report:
    warnings: list[str] = []
    lam = np.asarray(eigenvalues, dtype=float)
    z = np.asarray(probe_points, dtype=float)
    r = np.asarray(probe_values, dtype=float)

    if lam.shape != (3,) or z.shape != (2,) or r.shape != (2,):
        raise ValueError("Expected 3 eigenvalues, 2 probe points, and 2 probe values.")
    if not np.all(np.isfinite(lam)) or not np.all(np.isfinite(z)) or not np.all(np.isfinite(r)):
        raise ValueError("All inputs must be finite real numbers.")
    if tol <= 0.0 or conditioning_threshold <= 0.0 or irreducibility_threshold_sq <= 0.0:
        raise ValueError("All declared thresholds must be strictly positive.")

    lam = np.sort(lam)
    gaps = np.diff(lam)
    if np.min(gaps) <= tol:
        return D1Report(
            status="SPECTRAL_COLLISION",
            eigenvalues=lam.tolist(),
            probe_points=z.tolist(),
            probe_values=r.tolist(),
            weights=None,
            jacobi_matrix=None,
            determinant_A=None,
            sigma_min_A=None,
            condition_number_A=None,
            spectral_residual_l2=None,
            probe_residual_l2=None,
            positivity_margin=None,
            irreducibility_margin=None,
            warnings=["The ordered spectrum is not simple at the declared tolerance."],
        )

    if abs(z[0] - z[1]) <= tol:
        return D1Report(
            status="PROBE_DEPENDENCE",
            eigenvalues=lam.tolist(),
            probe_points=z.tolist(),
            probe_values=r.tolist(),
            weights=None,
            jacobi_matrix=None,
            determinant_A=None,
            sigma_min_A=None,
            condition_number_A=None,
            spectral_residual_l2=None,
            probe_residual_l2=None,
            positivity_margin=None,
            irreducibility_margin=None,
            warnings=["The two real probe points are not distinct."],
        )

    clearance = float(np.min(np.abs(z[:, None] - lam[None, :])))
    if clearance <= tol:
        return D1Report(
            status="PROBE_UNDEFINED",
            eigenvalues=lam.tolist(),
            probe_points=z.tolist(),
            probe_values=r.tolist(),
            weights=None,
            jacobi_matrix=None,
            determinant_A=None,
            sigma_min_A=None,
            condition_number_A=None,
            spectral_residual_l2=None,
            probe_residual_l2=None,
            positivity_margin=None,
            irreducibility_margin=None,
            warnings=["At least one probe point lies on the spectrum."],
        )

    A = build_augmented_cauchy(lam, z)
    svals = np.linalg.svd(A, compute_uv=False)
    sigma_min = float(svals[-1])
    det_A = float(np.linalg.det(A))
    cond_A = float(svals[0] / svals[-1])

    if sigma_min <= conditioning_threshold:
        warnings.append(
            f"LOW_STABILITY_MARGIN: sigma_min(A)={sigma_min:.6e} "
            f"<= threshold {conditioning_threshold:.6e}."
        )

    y = np.array([1.0, r[0], r[1]], dtype=float)
    weights = np.linalg.solve(A, y)
    sum_residual = abs(float(np.sum(weights) - 1.0))
    positivity_margin = float(np.min(weights))

    if sum_residual > 100 * tol:
        warnings.append(f"Normalization residual is {sum_residual:.6e}.")

    if positivity_margin <= tol:
        return D1Report(
            status="EMPTY_ADMISSIBLE_FIBER",
            eigenvalues=lam.tolist(),
            probe_points=z.tolist(),
            probe_values=r.tolist(),
            weights=weights.tolist(),
            jacobi_matrix=None,
            determinant_A=det_A,
            sigma_min_A=sigma_min,
            condition_number_A=cond_A,
            spectral_residual_l2=None,
            probe_residual_l2=None,
            positivity_margin=positivity_margin,
            irreducibility_margin=None,
            warnings=warnings + [
                "The unique algebraic weight vector is not strictly positive."
            ],
        )

    try:
        J = reconstruct_from_weights(lam, weights, tol)
    except ValueError as exc:
        return D1Report(
            status="IRREDUCIBILITY_NOT_CERTIFIED",
            eigenvalues=lam.tolist(),
            probe_points=z.tolist(),
            probe_values=r.tolist(),
            weights=weights.tolist(),
            jacobi_matrix=None,
            determinant_A=det_A,
            sigma_min_A=sigma_min,
            condition_number_A=cond_A,
            spectral_residual_l2=None,
            probe_residual_l2=None,
            positivity_margin=positivity_margin,
            irreducibility_margin=None,
            warnings=warnings + [str(exc)],
        )

    eig_reconstructed = np.linalg.eigvalsh(J)
    spectral_residual = float(np.linalg.norm(eig_reconstructed - lam, ord=2))
    probe_reconstructed = np.array([anchored_resolvent(J, zi) for zi in z])
    probe_residual = float(np.linalg.norm(probe_reconstructed - r, ord=2))
    irreducibility_margin = float(min(J[0, 1], J[1, 2]))
    irreducibility_margin_sq = float(min(J[0, 1] ** 2, J[1, 2] ** 2))
    if irreducibility_margin_sq <= irreducibility_threshold_sq:
        irreducibility_status = "IRREDUCIBILITY_MARGIN_LOW"
        warnings.append(
            f"IRREDUCIBILITY_MARGIN_LOW: min(b1^2,b2^2)={irreducibility_margin_sq:.6e} "
            f"<= threshold {irreducibility_threshold_sq:.6e}."
        )
    else:
        irreducibility_status = "IRREDUCIBILITY_CERTIFIED"

    verification_threshold = max(1e3 * tol, 1e-10)
    if spectral_residual > verification_threshold or probe_residual > verification_threshold:
        status = "CERTIFICATE_REJECTED"
        warnings.append(
            "Independent reconstruction verification exceeded the declared tolerance."
        )
    elif sigma_min <= conditioning_threshold or irreducibility_status == "IRREDUCIBILITY_MARGIN_LOW":
        status = "UNIQUE_WITH_LOW_STABILITY_MARGIN"
    else:
        status = "UNIQUE_MODULO_DECLARED_EQUIVALENCE"

    return D1Report(
        status=status,
        eigenvalues=lam.tolist(),
        probe_points=z.tolist(),
        probe_values=r.tolist(),
        weights=weights.tolist(),
        jacobi_matrix=J.tolist(),
        determinant_A=det_A,
        sigma_min_A=sigma_min,
        condition_number_A=cond_A,
        spectral_residual_l2=spectral_residual,
        probe_residual_l2=probe_residual,
        positivity_margin=positivity_margin,
        irreducibility_margin=irreducibility_margin,
        warnings=warnings,
        spectral_separation_margin=float(np.min(gaps)),
        probe_clearance_margin=clearance,
        probe_independence_margin=float(abs(z[0] - z[1])),
        irreducibility_margin_sq=irreducibility_margin_sq,
        irreducibility_threshold_sq=irreducibility_threshold_sq,
        irreducibility_status=irreducibility_status,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Reconstruct a real 3x3 Jacobi matrix from two anchored resolvent probes."
    )
    parser.add_argument(
        "--eigenvalues",
        nargs=3,
        type=float,
        metavar=("L1", "L2", "L3"),
        default=[-1.0, 1.0, 3.0],
    )
    parser.add_argument(
        "--probe-points",
        nargs=2,
        type=float,
        metavar=("Z1", "Z2"),
        default=[0.0, 2.0],
    )
    parser.add_argument(
        "--probe-values",
        nargs=2,
        type=float,
        metavar=("R1", "R2"),
        default=[-1.0 / 3.0, 1.0 / 3.0],
    )
    parser.add_argument("--tol", type=float, default=1e-10)
    parser.add_argument("--conditioning-threshold", type=float, default=1e-8)
    parser.add_argument(
        "--irreducibility-threshold-sq",
        type=float,
        default=1e-6,
        help=(
            "Preregistered lower threshold for min(b1^2,b2^2). "
            "Values above numerical zero but below this threshold trigger "
            "IRREDUCIBILITY_MARGIN_LOW."
        ),
    )
    parser.add_argument(
        "--compact",
        action="store_true",
        help="Emit compact JSON instead of indented JSON.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    report = reconstruct(
        args.eigenvalues,
        args.probe_points,
        args.probe_values,
        tol=args.tol,
        conditioning_threshold=args.conditioning_threshold,
        irreducibility_threshold_sq=args.irreducibility_threshold_sq,
    )
    print(
        json.dumps(
            asdict(report),
            ensure_ascii=False,
            indent=None if args.compact else 2,
        )
    )
    return 0 if report.status.startswith("UNIQUE") else 2


if __name__ == "__main__":
    raise SystemExit(main())
