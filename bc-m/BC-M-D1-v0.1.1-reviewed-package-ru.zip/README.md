# BC-M-D1 v0.1.1 reviewed package

## Title

**BC-M-D1: Minimal Anchored Reconstruction of a 3x3 Jacobi Matrix**

Russian reviewed technical note and computational companion for the Boundary Compensation / BC-M programme.

## Contents

- `BC-M-D1-v0.1.1-reviewed-ru.pdf` - reviewed Russian manuscript.
- `BC-M-D1-v0.1.1-reviewed-ru.tex` - XeLaTeX source.
- `BC-M-D1-jacobi-reconstruction-v0.1.1.py` - NumPy computational companion.
- `BC-M-D1-example-report-v0.1.1.json` - output for the built-in exact example.
- `CHANGELOG-BC-M-D1-v0.1.1.md` - reviewed-revision notes.

## Default example

- eigenvalues: `-1, 1, 3`
- real probe points: `0, 2`
- probe values: `-1/3, 1/3`

The exact reconstruction is

```text
[[1, sqrt(2), 0],
 [sqrt(2), 1, sqrt(2)],
 [0, sqrt(2), 1]].
```

## Run

```bash
python BC-M-D1-jacobi-reconstruction-v0.1.1.py
```

Custom data:

```bash
python BC-M-D1-jacobi-reconstruction-v0.1.1.py \
  --eigenvalues -1 1 3 \
  --probe-points 0 2 \
  --probe-values -0.3333333333333333 0.3333333333333333 \
  --irreducibility-threshold-sq 1e-6
```

## Irreducibility-margin protocol

The script distinguishes:

- `b_i^2 <= tol`: irreducibility is not certified;
- `0 < min(b1^2,b2^2) <= omega_irr`: exact positivity holds, but the report records `IRREDUCIBILITY_MARGIN_LOW`;
- `min(b1^2,b2^2) > omega_irr`: `IRREDUCIBILITY_CERTIFIED`.

The threshold `omega_irr` is a preregistered certification-policy parameter, not a physical constant.

## Compile manuscript

```bash
latexmk -xelatex BC-M-D1-v0.1.1-reviewed-ru.tex
```

## Scope

The manuscript is a bounded object-level demonstration of BC-M realization geometry. The code is a finite-dimensional reproducibility aid. Neither is a certified floating-point package, detector model, physical tomography protocol, proof engine, or hidden-reality reconstruction theorem.

## Authorship and review

A. A. Malachevsky is the sole author and scientific decision maker. Independent reviewer comments were treated as review material; they do not create authorship or coauthorship.
