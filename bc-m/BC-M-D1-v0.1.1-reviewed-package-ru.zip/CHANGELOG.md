# CHANGELOG - BC-M-D1 v0.1.1

## Status

Reviewed minor revision after two independent audits. The core theorem set remains unchanged.

## Manuscript changes

1. Added a formal BC-M I handoff:
   - ambient tridiagonal realization class;
   - preregistered positive-off-diagonal admissibility class;
   - exact admissible fiber identity
     `F_adm(0,lambda) = Pi_0^{-1}(lambda) intersect C_J = J_lambda`.

2. Strengthened protocol-relative minimality:
   - added an explicit nonreal complex-probe example with nonzero real-system determinant;
   - retained the claim that two probes are minimal only within real scalar point evaluations at real probe points.

3. Strengthened finite-resolution analysis:
   - defined the derivative-based constant
     `L_(lambda,omega) = max ||D J_lambda(w)||`;
   - made compactness and convexity assumptions explicit;
   - promoted the `epsilon = 10^-3` reference calculation to a numbered numerical tube certificate.

4. Strengthened anti-retrofitting discipline:
   - probe points, tolerance model, numerical thresholds, irreducibility threshold, and sign convention must be fixed before inspection of the target reconstruction.

5. Added a BC-Emergence handoff without claiming emergence:
   - defined `Q(J) = a_2(J)`;
   - supplied an explicit pair with the same spectrum and the same first probe but different values of `Q`;
   - classified it only as a candidate non-factorization witness.

6. Added the failure-state diagnostic `IRREDUCIBILITY_MARGIN_LOW`.

## Software changes

1. Added command-line option:

```text
--irreducibility-threshold-sq
```

2. Added report fields:

- `spectral_separation_margin`
- `probe_clearance_margin`
- `probe_independence_margin`
- `irreducibility_margin_sq`
- `irreducibility_threshold_sq`
- `irreducibility_status`

3. Strict failure and low-margin warning are now separated.

4. The built-in example remains exactly reconstructed and returns:

```text
UNIQUE_MODULO_DECLARED_EQUIVALENCE
IRREDUCIBILITY_CERTIFIED
```

## Authorship

Authorship is unchanged. Reviewer suggestions are acknowledged as independent review input, not coauthorship.
